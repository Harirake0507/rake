package com.jailer2.alert;

import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

public class BmsChecker {
    static final String URL = "https://in.bookmyshow.com/movies/chennai/jailer-2/ET00518674";

    public static class Result {
        public final boolean bookingOpen;
        public final String reason;
        public final List<String> matchedTheatres;
        Result(boolean bookingOpen, String reason, List<String> matchedTheatres) {
            this.bookingOpen = bookingOpen;
            this.reason = reason;
            this.matchedTheatres = matchedTheatres;
        }
    }

    static Result check() {
        HttpURLConnection c = null;
        try {
            URL u = new URL(URL);
            c = (HttpURLConnection) u.openConnection();
            c.setRequestMethod("GET");
            c.setConnectTimeout(7000);
            c.setReadTimeout(7000);
            c.setInstanceFollowRedirects(true);
            c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/140 Mobile Safari/537.36");
            c.setRequestProperty("Accept-Language", "en-IN,en;q=0.9");
            c.setRequestProperty("Accept", "text/html,application/xhtml+xml");
            int code = c.getResponseCode();
            if (code < 200 || code >= 400) return new Result(false, "BMS HTTP " + code, Collections.emptyList());

            BufferedReader r = new BufferedReader(new InputStreamReader(c.getInputStream(), StandardCharsets.UTF_8));
            StringBuilder s = new StringBuilder();
            String line;
            while ((line = r.readLine()) != null) s.append(line).append('\n');
            String x = s.toString().toLowerCase(Locale.ROOT);

            boolean interested = x.contains("mark interested");
            boolean book = x.contains("book tickets") || x.contains("book now") ||
                    x.contains("showtimes") || x.contains("select showtime") ||
                    x.contains("buy tickets") || x.contains("available");
            boolean blocked = x.contains("captcha") || x.contains("access denied") ||
                    x.contains("too many requests");

            List<String> theatres = new ArrayList<>();
            for (String theatre : MainActivity.THEATRES) {
                String key = theatre.toLowerCase(Locale.ROOT);
                String simplified = key.replace(":", "").replace("-", "").replace(" ", "");
                String compact = x.replace(":", "").replace("-", "").replace(" ", "");
                if (compact.contains(simplified)) theatres.add(theatre);
            }

            if (blocked) return new Result(false, "BMS protection/limit detected", theatres);
            if (book && !interested) return new Result(true, "Booking/showtime indicators detected", theatres);
            return new Result(false, interested ? "Still showing Mark interested" : "No booking indicator yet", theatres);
        } catch (Exception e) {
            return new Result(false, "Network error: " + e.getClass().getSimpleName(), Collections.emptyList());
        } finally {
            if (c != null) c.disconnect();
        }
    }

    static boolean isBookingOpen() { return check().bookingOpen; }
}
