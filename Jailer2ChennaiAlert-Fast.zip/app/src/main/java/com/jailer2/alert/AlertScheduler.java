package com.jailer2.alert;

import android.app.*;
import android.content.*;
import java.util.*;

public class AlertScheduler {
    static void schedule(Context c) {
        if (!AlertReceiver.withinWindow()) return;
        AlarmManager am = (AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
        Intent i = new Intent(c, AlertReceiver.class);
        PendingIntent pi = PendingIntent.getBroadcast(c, 88, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        long next = System.currentTimeMillis() + 30L * 60L * 1000L; // every 30 minutes
        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next, pi);
    }
}
