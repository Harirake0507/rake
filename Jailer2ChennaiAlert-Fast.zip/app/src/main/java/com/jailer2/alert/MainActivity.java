package com.jailer2.alert;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.*;
import android.view.*;
import android.widget.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    static final String BMS_URL = "https://in.bookmyshow.com/movies/chennai/jailer-2/ET00518674";
    static final String END_DATE = "2026-10-14";
    static final String[] THEATRES = {
        "Rohini Silver Screens: Koyambedu", "VETTRIVEL RGB DOLBY: Nanganallur",
        "PVR: Sathyam, Royapettah", "PVR: VR Chennai, Anna Nagar",
        "INOX: LUXE Phoenix Market City, Velachery", "HDFC Millennia PVR: Escape-Express Avenue Mall",
        "PVR: Palazzo, The Nexus Vijaya Mall", "PVR: Ampa Mall, Nelson Manickam Road",
        "PVR: Grand Mall, Velachery", "PVR: Grand Galada, Pallavaram",
        "PVR: Perambur, Spectrum Mall", "PVR: Heritage RSL ECR, Chennai",
        "PVR: Aerohub, Chennai", "PVR: SKLS Galaxy Mall, Red Hills Chennai",
        "MAYAJAAL Multiplex: ECR, Chennai", "KC(KrishnaveniCinemas) RG3 LASER DOLBYATMOS TNAGAR",
        "Medavakkam Kumaran Cinemas RGB LASER Dolby Atmos", "Rakki Cinemas: OMR, Kelambakkam",
        "Gokulam Cinemas 4K Dolby Atmos: Poonamalle", "The Vijay Park Multiplex: Injambakkam ECR 4K Atmos",
        "INOX: The Marina Mall, OMR", "AGS Cinemas: T. Nagar", "AGS Cinemas: Villivakkam",
        "Cinepolis: BSR Mall, OMR, Thoraipakkam", "INOX: Chennai Citi Centre, Dr. RK Salai",
        "INOX National: Arcot Road", "AGS Cinemas OMR: Navlur", "Vels Theatres: Chennai",
        "Sivasakthi Cinemas RGB 4K Laser: Padi", "Kasi Talkies Dolby Atmos: Ashok Nagar"
    };
    LinearLayout list;
    TextView status;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        buildUi();
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 10);
    }

    void buildUi() {
        ScrollView sv = new ScrollView(this);
        list = new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL); list.setPadding(28,32,28,32); list.setBackgroundColor(Color.rgb(16,17,20)); sv.addView(list);
        list.addView(tv("🐯 JAILER 2 — CHENNAI",26,Color.WHITE));
        list.addView(tv("Release: 15 Oct 2026 • Watch bookings through 14 Oct",15,Color.LTGRAY));
        status = tv("10-second monitor is OFF",15,Color.rgb(255,176,0)); status.setPadding(0,22,0,16); list.addView(status);

        Button start = new Button(this); start.setText("START 10-SECOND MONITOR");
        start.setOnClickListener(v -> startMonitor()); list.addView(start);
        Button stop = new Button(this); stop.setText("STOP MONITOR"); stop.setOnClickListener(v -> stopMonitor()); list.addView(stop);

        Button check = new Button(this); check.setText("CHECK BOOKMYSHOW NOW");
        check.setOnClickListener(v -> {
            status.setText("Checking BMS…");
            new Thread(() -> { BmsChecker.Result r = BmsChecker.check(); runOnUiThread(() -> {
                status.setText(r.bookingOpen ? "🟢 BOOKING/SHOWTIME STATE DETECTED" : "🟡 Not open yet • " + r.reason);
                if (r.bookingOpen) AlertReceiver.notifyOpen(this, r.matchedTheatres);
            }); }).start();
        }); list.addView(check);

        Button open = new Button(this); open.setText("OPEN BOOKMYSHOW"); open.setOnClickListener(v -> startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(BMS_URL)))); list.addView(open);
        list.addView(tv("CHENNAI THEATRES",20,Color.WHITE));
        list.addView(tv("Current Chennai cinema names cross-checked against BookMyShow's Chennai cinema directory. This list is a watch list; only BMS's live movie/showtime data can confirm which theatres get Jailer 2.",13,Color.LTGRAY));
        for (String t : THEATRES) { TextView row=tv("• "+t,15,Color.WHITE); row.setPadding(0,8,0,8); list.addView(row); }
        list.addView(tv("\nHow fast mode works",20,Color.WHITE));
        list.addView(tv("While you start the monitor, the app keeps a visible foreground notification and checks the public BMS movie page about every 10 seconds. It alerts once when booking/showtime indicators appear. Android does not guarantee 10-second background execution, so this fast mode is intentionally user-started and visible.",14,Color.LTGRAY));
        setContentView(sv);
    }

    void startMonitor() {
        Intent i = new Intent(this, MonitorService.class);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
        status.setText("🟢 10-second monitor RUNNING • until 14 Oct 2026");
    }
    void stopMonitor() { startService(new Intent(this, MonitorService.class).setAction(MonitorService.ACTION_STOP)); status.setText("10-second monitor is OFF"); }
    TextView tv(String s,int size,int color){ TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); return t; }
}
