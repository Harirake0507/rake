package com.jailer2.alert;

import android.app.*;
import android.content.*;
import android.os.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class MonitorService extends Service {
    public static final String ACTION_START = "com.jailer2.alert.START";
    public static final String ACTION_STOP = "com.jailer2.alert.STOP";
    static final int NOTIFICATION_ID = 2001;
    static final long INTERVAL_MS = 10_000L;
    static final String CHANNEL = "jailer2_monitor";
    final Handler handler = new Handler(Looper.getMainLooper());
    boolean running = false;
    boolean alerted = false;
    long checks = 0;

    final Runnable loop = new Runnable() {
        @Override public void run() {
            if (!running) return;
            checks++;
            new Thread(() -> {
                BmsChecker.Result result = BmsChecker.check();
                long now = System.currentTimeMillis();
                String time = new SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new Date(now));
                updateNotification("Last check " + time + " • #" + checks + " • " + result.reason);
                if (result.bookingOpen && !alerted) {
                    alerted = true;
                    AlertReceiver.notifyOpen(MonitorService.this, result.matchedTheatres);
                }
                if (new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date(now)).compareTo(MainActivity.END_DATE) > 0) {
                    stopMonitoring();
                } else if (running) {
                    handler.postDelayed(this, INTERVAL_MS);
                }
            }).start();
        }
    };

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (ACTION_STOP.equals(intent != null ? intent.getAction() : null)) {
            stopMonitoring();
            return START_NOT_STICKY;
        }
        createChannel();
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIFICATION_ID, buildNotification("Starting 10-second monitoring…"), 0x4000);
        } else {
            startForeground(NOTIFICATION_ID, buildNotification("Starting 10-second monitoring…"));
        }
        running = true;
        handler.removeCallbacks(loop);
        handler.post(loop);
        return START_NOT_STICKY;
    }

    void stopMonitoring() {
        running = false;
        handler.removeCallbacksAndMessages(null);
        stopForeground(STOP_FOREGROUND_REMOVE);
        stopSelf();
    }

    void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager nm = getSystemService(NotificationManager.class);
            nm.createNotificationChannel(new NotificationChannel(CHANNEL, "Jailer 2 monitoring", NotificationManager.IMPORTANCE_LOW));
        }
    }

    Notification buildNotification(String text) {
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this, 1, open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification.Builder builder = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CHANNEL)
                : new Notification.Builder(this);
        return builder
                .setContentTitle("Jailer 2 Chennai monitor")
                .setContentText(text)
                .setSmallIcon(android.R.drawable.ic_popup_sync)
                .setOngoing(true)
                .setContentIntent(pi)
                .build();
    }

    void updateNotification(String text) {
        NotificationManager nm = getSystemService(NotificationManager.class);
        nm.notify(NOTIFICATION_ID, buildNotification(text));
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
