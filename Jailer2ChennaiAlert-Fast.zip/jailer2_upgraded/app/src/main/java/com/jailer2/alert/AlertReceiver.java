package com.jailer2.alert;

import android.app.*;
import android.content.*;
import android.net.Uri;
import java.util.*;

public class AlertReceiver extends BroadcastReceiver {
    static final String CHANNEL = "jailer2_alerts";
    static final int ALERT_ID = 3001;

    public static void notifyOpen(Context context) { notifyOpen(context, Collections.emptyList()); }

    public static void notifyOpen(Context context, List<String> theatres) {
        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (android.os.Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(new NotificationChannel(CHANNEL, "Booking alerts", NotificationManager.IMPORTANCE_HIGH));
        }
        String text = theatres == null || theatres.isEmpty()
                ? "BookMyShow appears to have opened booking/showtimes."
                : "Booking detected • " + theatres.size() + " theatre name(s) found on the page.";
        Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(MainActivity.BMS_URL));
        PendingIntent pi = PendingIntent.getActivity(context, 2, i, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification n = new Notification.Builder(context, CHANNEL)
                .setContentTitle("🎟️ Jailer 2 booking alert")
                .setContentText(text)
                .setStyle(new Notification.BigTextStyle().bigText(text + "\nTap to open BookMyShow."))
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setAutoCancel(true)
                .setContentIntent(pi)
                .build();
        nm.notify(ALERT_ID, n);
    }

    @Override public void onReceive(Context context, Intent intent) { }
}
