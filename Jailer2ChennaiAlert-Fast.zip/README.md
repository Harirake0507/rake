# Jailer 2 Chennai Alert — fast mode

Android tracker for the BookMyShow Chennai Jailer 2 page.

- Movie release: **15 Oct 2026**.
- Monitoring cutoff: **end of 14 Oct 2026**.
- **Fast mode:** user starts a visible foreground monitor that checks about every **10 seconds**.
- Sends a high-priority notification when the public BMS movie page appears to enter a booking/showtime state.
- Shows a current Chennai theatre watch list based on the BookMyShow Chennai cinema directory.
- Attempts to identify theatre names when they appear in the fetched movie-page HTML.
- Does not bypass login, CAPTCHA, bot protection, rate limits, or private/internal APIs.

## Important limitation
BMS can change its HTML, APIs, anti-bot behavior, or booking flow. This app only uses the public movie page and conservative text detection. It cannot guarantee that a theatre is selling tickets until BMS exposes that information publicly.

## Android behavior
The 10-second mode is deliberately a **user-started foreground service** with a visible notification. Android restricts arbitrary high-frequency background execution, and newer Android versions impose additional foreground-service rules, so a hidden always-on 10-second loop is not promised.

## Build
Use Android Studio or the included GitHub Actions workflow. The workflow generates the Gradle wrapper and builds `app-debug.apk`.
